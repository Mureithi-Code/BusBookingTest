import os
from flask import Flask
from app.extensions import db, jwt, cors, bcrypt  # Use existing instances
from flask_migrate import Migrate  # Add Migrate
from app.config import Config
from flask_restx import Api

def create_app():
    """Factory function to create and configure the Flask app."""
    app = Flask(__name__)
    api = Api(app, title="Bus Booking API", version="1.0", description="API documentation for Bus Booking System")
    
    

    # Load Configuration
    app.config.from_object(Config)

    # Initialize Extensions
    db.init_app(app)
    jwt.init_app(app)
    cors.init_app(app)  # Use `cors` from extensions.py
    bcrypt.init_app(app)
    
    # Initialize Flask-Migrate
    migrate = Migrate(app, db)  # ✅ Add this

    # Register Blueprints (Routes)
    # from app.routes.admin_routes import admin_bp
    # from app.routes.driver_routes import driver_bp
    # from app.routes.customer_routes import customer_bp
    # from app.routes.auth_routes import auth_bp

    # app.register_blueprint(admin_bp, url_prefix='/admin')
    # app.register_blueprint(driver_bp, url_prefix='/driver')
    # app.register_blueprint(customer_bp, url_prefix='/customer')
    # app.register_blueprint(auth_bp, url_prefix='/auth')
    
    # Import and register namespaces
    from app.routes.auth_routes import auth_ns
    from app.routes.admin_routes import admin_ns
    from app.routes.customer_routes import customer_ns
    from app.routes.driver_routes import driver_ns

    api.add_namespace(auth_ns, path="/auth")
    api.add_namespace(admin_ns, path="/admin")
    api.add_namespace(customer_ns, path="/customer")
    api.add_namespace(driver_ns, path="/driver")

    return app
